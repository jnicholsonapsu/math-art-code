/* ===========================================================
   STEP 8 — PICKING YOUR OWN COLORS
   ===========================================================

   In this step, you pick your own colors.

   Replace your palette with the marked lines below. That
   gives you three colors, all black for now.

   Then go to the palette and change each color(0, 0, 0) to a
   color you choose. Keep every color different from the
   paper color.

   Each number in a color must be a whole number from 0 up
   to and including 255.

   =========================================================== */

// ---------- THE PAGE ------------------------------------
int pageWidth = 612;     // 8.5 inches when printed
int pageHeight = 792;    // 11 inches when printed

// ---------- THE GRID ------------------------------------
int numberOfColumns = 6;
int numberOfRows = 8;
float sizeRatio = 1.0;

// ---------- THE LOOK ------------------------------------
// ******************************************
// ***** REPLACE YOUR PALETTE WITH THIS *****
// ******************************************
// Replace each (0, 0, 0) triplet with values from
// https://paletton.com/
color[] palette = {
  color(0, 0, 0),   // 3 whole numbers, each from 0 to 255
  color(0, 0, 0),   // 3 whole numbers, each from 0 to 255
  color(0, 0, 0),   // 3 whole numbers, each from 0 to 255
};

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
float cellWidth = pageWidth / float(numberOfColumns);
float cellHeight = pageHeight / float(numberOfRows);
float diameter = min(cellWidth, cellHeight) * sizeRatio;

// ---------- THE DRAWING ---------------------------------
void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);   // one pixel for every point on the page
}

void setup() {
  noLoop();   // draw once, then wait
}

void draw() {
  background(255, 255, 255);
  noStroke();

  for (int column = 0; column < numberOfColumns; column++) {
    for (int row = 0; row < numberOfRows; row++) {

      float centerX = column * cellWidth + cellWidth / 2;
      float centerY = row * cellHeight + cellHeight / 2;

      int whichCircleColor = int(random(palette.length));   // 0 to 2
      fill(palette[whichCircleColor]);

      ellipse(centerX, centerY, diameter, diameter);
    }
  }
}

/* ===========================================================
   Notes:

   HOW DO YOUR COLORS LOOK TOGETHER?

   There is a good chance your three colors do not work well
   together. That is normal. Colors picked without a plan
   clash more often than they match, even when each one looks
   fine on its own.

   PICKING COLORS THAT GO TOGETHER

   Color theory is a set of rules for picking colors that work
   well together. Most of the rules use a color wheel. Three
   common rules are:

       complementary   two colors opposite each other
       analogous       colors next to each other
       triadic         three colors spaced evenly around
                       the wheel

   Triadic and analogous each give three colors, one for each
   line in your palette.

   Go to

       https://paletton.com/

   Above the large colorful circle is a row of small
   circles. Select the one with 3 dots in a triangle. The
   label to the right of the small circles should say
   "Triadic (3 colors)".

   Move the dots in the large colorful circle until you find
   colors you like.

   On the right, click on a color. A box opens. Click on the
   3 numbers next to the label "RGB[0-255]" to copy them.

   Paste the three numbers over the 0, 0, 0 in one of the
   color(0, 0, 0) lines in your palette, so it reads
   something like

       color(121, 165, 236)

   Do the same for the other two colors, and press PLAY.

   You don't always have to use Triadic, which gives three
   colors. The other choices on Paletton work too. Just make
   sure your palette has one color line for each color the
   rule gives you. The palette.length takes care of the rest,
   as in step 7.

   =========================================================== */
