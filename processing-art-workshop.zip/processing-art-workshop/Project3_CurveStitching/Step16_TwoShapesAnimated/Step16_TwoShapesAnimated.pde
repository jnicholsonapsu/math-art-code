/* ===========================================================
   STEP 16 — TWO SHAPES, ANIMATED
   ===========================================================

   An animation of Step 15. Each shape is drawn in the same
   color as the point that goes around it.
   Press PLAY and watch. The first few samples go slowly:
   pick a random angle t, find point 1 on the first shape and
   point 2 on the second shape, then pick a random spot u
   along the line between them and count it. Then it speeds
   up, and the counts build up the picture.

   Pick the shapes, their sizes and the speeds the same way
   as in Step 15.

   =========================================================== */

// ---------- THE PAGE ------------------------------------
int pageWidth = 612;     // 8.5 inches when printed
int pageHeight = 792;    // 11 inches when printed
float pageMargin = 72 / 4.0;   // a quarter inch when printed

// ---------- THE SHAPES ----------------------------------
// Pick a shape for each point. The choices are:
//
//   new Rose(k)                  k sets the petals, as in Step 5
//   new Square(rotation)         rotation turns it, as in Step 7
//   new Lemniscate()             a sideways figure eight, Step 9
//   new Hypotrochoid(R, r, d)    rolling circles, as in Step 11
//   new Lissajous(a, b, delta)   swings, as in Step 13
//
// Both points can go around the same kind of shape.

Shape shapeOne = new Rose(2);                 // point one goes around this
Shape shapeTwo = new Hypotrochoid(5, 3, 2);   // point two goes around this

float shapeOneSize = 1.0;   // 1 is as big as fits on the page
float shapeTwoSize = 1.0;   // 0.5 is half as big

int pointOneSpeed = 1;   // how many times point one goes around
int pointTwoSpeed = 2;   // how many times point two goes around

// ---------- THE ANIMATION -------------------------------
int slowSamples = 8;           // how many samples to show one at a time
int framesPerSample = 90;      // how long each slow sample takes
int speedUp = 8;               // how fast the samples per frame grow
int mostSamplesPerFrame = 20000;
int totalSamples = 1000000;
int pauseFrames = 240;         // how long the finished picture stays
                               // on screen before it starts again

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);        // white
color primaryColor = color( 30,  60, 140);      // navy
color sampleLineColor = color(150, 150, 150);   // gray
color spotColor = color(230, 120,  30);         // orange
color pointOneColor = color(170,  51, 119);     // purple
color pointTwoColor = color(  0, 158, 115);     // bluish green
color textColor = color(  0,   0,   0);         // black
float pointSize = 14;
float spotSize = 8;
float labelSize = 18;
float labelGap = 20;   // how far a label sits outside its point
int outlinePoints = 2000;   // how many points draw each gray shape

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
float centerX = pageWidth / 2;
float centerY = pageHeight / 2;

// how far a shape of size 1 reaches from the center, as big
// as fits inside the margins
float shapeRadius = min(pageWidth, pageHeight) / 2 - pageMargin;

// how many trips around it takes for both shapes to close
int trips = shapeOne.trips() * shapeTwo.trips();

// ---------- THE DRAWING ---------------------------------
int[] counts = new int[pageWidth * pageHeight];
int biggestCount = 0;
int samplesDone = 0;
PImage picture;
boolean pictureIsOutOfDate = false;

// the slow samples
float t;
float u;
int frameInSample = 0;
float[] spotX = new float[slowSamples];
float[] spotY = new float[slowSamples];

// the fast samples
int fastFrame = 0;
int pauseFramesLeft = 0;

void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);
  smooth(8);
}

void setup() {
  picture = createImage(pageWidth, pageHeight, RGB);
  startOver();
}

void startOver() {
  for (int pixelNumber = 0; pixelNumber < counts.length; pixelNumber++) {
    counts[pixelNumber] = 0;
  }
  biggestCount = 0;
  samplesDone = 0;
  frameInSample = 0;
  fastFrame = 0;
  pictureIsOutOfDate = true;
}

void draw() {
  if (pauseFramesLeft > 0) {
    pauseFramesLeft--;
    if (pauseFramesLeft == 0) {
      startOver();
    }
  } else if (samplesDone >= slowSamples) {
    int samplesThisFrame = min((fastFrame + 1) * speedUp, mostSamplesPerFrame);
    samplesThisFrame = min(samplesThisFrame, totalSamples - samplesDone);
    for (int sampleNumber = 0; sampleNumber < samplesThisFrame; sampleNumber++) {
      float sampleT = random(TWO_PI * trips);
      float sampleU = random(1);
      PVector spot = spotPoint(sampleT, sampleU);
      addCount(spot.x, spot.y);
    }
    fastFrame++;
    if (samplesDone >= totalSamples) {
      pauseFramesLeft = pauseFrames;
    }
  }

  if (pictureIsOutOfDate) {
    updatePicture();
  }

  background(paperColor);
  image(picture, 0, 0);

  drawOutline(1);
  drawOutline(2);

  textSize(labelSize);
  if (samplesDone < slowSamples && pauseFramesLeft == 0) {
    drawSlowSample();
  } else {
    fill(textColor);
    textAlign(CENTER, TOP);
    text(nfc(samplesDone) + " samples", centerX, 10);
  }
}

// Shape 1 or shape 2, drawn as a thin line in its point's color
void drawOutline(int shapeNumber) {
  noFill();
  if (shapeNumber == 1) {
    stroke(pointOneColor);
  } else {
    stroke(pointTwoColor);
  }
  strokeWeight(1);
  beginShape();
  for (int pointNumber = 0; pointNumber <= outlinePoints; pointNumber++) {
    float t = TWO_PI * trips * pointNumber / outlinePoints;
    PVector point;
    if (shapeNumber == 1) {
      point = pointOneAt(t);
    } else {
      point = pointTwoAt(t);
    }
    vertex(point.x, point.y);
  }
  endShape();
}

// One sample, shown in three parts: the two points and their
// line, then the spot sliding along to u, then the spot held
void drawSlowSample() {
  if (frameInSample == 0) {
    t = random(TWO_PI * trips);
    u = random(1);
  }
  int partLength = framesPerSample / 3;

  // the spots from earlier samples
  noStroke();
  fill(spotColor);
  for (int spotNumber = 0; spotNumber < samplesDone; spotNumber++) {
    circle(spotX[spotNumber], spotY[spotNumber], spotSize);
  }

  PVector pointOne = pointOneAt(t);
  PVector pointTwo = pointTwoAt(t);

  stroke(sampleLineColor);
  strokeWeight(1.5);
  line(pointOne.x, pointOne.y, pointTwo.x, pointTwo.y);

  noStroke();
  fill(pointOneColor);
  circle(pointOne.x, pointOne.y, pointSize);
  fill(pointTwoColor);
  circle(pointTwo.x, pointTwo.y, pointSize);

  textAlign(CENTER, CENTER);
  fill(pointOneColor);
  PVector labelOne = labelPoint(pointOne);
  text("1", labelOne.x, labelOne.y);
  fill(pointTwoColor);
  PVector labelTwo = labelPoint(pointTwo);
  text("2", labelTwo.x, labelTwo.y);

  // the spot slides from point 1 to u
  String caption = "sample " + (samplesDone + 1) + ",   t = " + nf(t, 1, 2);
  if (frameInSample >= partLength) {
    float slide = min(1, (float) (frameInSample - partLength) / partLength);
    float shownU = u * slide;
    PVector spot = spotPoint(t, shownU);
    fill(spotColor);
    circle(spot.x, spot.y, spotSize);
    caption += ",   u = " + nf(shownU, 1, 2);
  }
  fill(textColor);
  textAlign(CENTER, TOP);
  text(caption, centerX, 10);

  frameInSample++;
  if (frameInSample == framesPerSample) {
    PVector spot = spotPoint(t, u);
    spotX[samplesDone] = spot.x;
    spotY[samplesDone] = spot.y;
    addCount(spot.x, spot.y);
    frameInSample = 0;
  }
}

// Where a label goes: labelGap past the point, away from the
// center of the page
PVector labelPoint(PVector point) {
  float awayX = point.x - centerX;
  float awayY = point.y - centerY;
  float distance = max(1, sqrt(awayX * awayX + awayY * awayY));
  return new PVector(point.x + labelGap * awayX / distance,
                     point.y + labelGap * awayY / distance);
}

void addCount(float x, float y) {
  samplesDone++;
  int column = round(x);
  int row = round(y);
  if (column < 0 || column >= pageWidth || row < 0 || row >= pageHeight) {
    return;   // off the page
  }
  int pixelNumber = row * pageWidth + column;
  counts[pixelNumber]++;
  biggestCount = max(biggestCount, counts[pixelNumber]);
  pictureIsOutOfDate = true;
}

void updatePicture() {
  picture.loadPixels();
  float logOfBiggest = log(1 + biggestCount);
  for (int pixelNumber = 0; pixelNumber < counts.length; pixelNumber++) {
    float darkness = 0;
    if (counts[pixelNumber] > 0) {
      darkness = log(1 + counts[pixelNumber]) / logOfBiggest;
    }
    picture.pixels[pixelNumber] = lerpColor(paperColor, primaryColor, darkness);
  }
  picture.updatePixels();
  pictureIsOutOfDate = false;
}

// Where the spot u of the way along the line at angle t is
PVector spotPoint(float t, float u) {
  PVector pointOne = pointOneAt(t);
  PVector pointTwo = pointTwoAt(t);
  float x = (1 - u) * pointOne.x + u * pointTwo.x;
  float y = (1 - u) * pointOne.y + u * pointTwo.y;
  return new PVector(x, y);
}

// Where point one is at angle t
PVector pointOneAt(float t) {
  PVector point = shapeOne.point(t * pointOneSpeed);
  float x = centerX + shapeRadius * shapeOneSize * point.x;
  float y = centerY + shapeRadius * shapeOneSize * point.y;
  return new PVector(x, y);
}

// Where point two is at angle t
PVector pointTwoAt(float t) {
  PVector point = shapeTwo.point(t * pointTwoSpeed);
  float x = centerX + shapeRadius * shapeTwoSize * point.x;
  float y = centerY + shapeRadius * shapeTwoSize * point.y;
  return new PVector(x, y);
}

// ---------- THE SHAPES ----------------------------------
// Each shape says where its point is at angle theta. Every
// shape reaches 1 from its center, and pointOneAt() and
// pointTwoAt() make it bigger to fit the page.

class Shape {
  PVector point(float theta) {
    return new PVector(0, 0);
  }

  // how many trips around before the shape closes
  int trips() {
    return 1;
  }
}

// Step 5: a rose
class Rose extends Shape {
  int k;

  Rose(int k) {
    this.k = k;
  }

  PVector point(float theta) {
    float x = cos(k * theta) * cos(theta);
    float y = cos(k * theta) * sin(theta);
    return new PVector(x, y);
  }
}

// Step 7: a square, 1 from the center to each side
class Square extends Shape {
  float rotation;

  Square(float rotation) {
    this.rotation = rotation;
  }

  PVector point(float theta) {
    // the same angle, moved into the range 0 up to TWO_PI
    float angle = theta % TWO_PI;
    if (angle < 0) {
      angle += TWO_PI;
    }

    // where a line from the center at this angle crosses the
    // edge of a square that reaches from -1 to 1
    float edgeX;
    float edgeY;
    if (angle >= QUARTER_PI && angle < 3 * QUARTER_PI) {
      edgeX = cos(angle) / sin(angle);   // the bottom edge
      edgeY = 1;
    } else if (angle >= 3 * QUARTER_PI && angle < 5 * QUARTER_PI) {
      edgeX = -1;                        // the left edge
      edgeY = -tan(angle);
    } else if (angle >= 5 * QUARTER_PI && angle < 7 * QUARTER_PI) {
      edgeX = -cos(angle) / sin(angle);  // the top edge
      edgeY = -1;
    } else {
      edgeX = 1;                         // the right edge
      edgeY = tan(angle);
    }

    // turn it by rotation
    float x = edgeX * cos(rotation) - edgeY * sin(rotation);
    float y = edgeY * cos(rotation) + edgeX * sin(rotation);
    return new PVector(x, y);
  }
}

// Step 9: a lemniscate
class Lemniscate extends Shape {
  PVector point(float theta) {
    float x = cos(theta) / (1 + sin(theta) * sin(theta));
    float y = sin(theta) * cos(theta) / (1 + sin(theta) * sin(theta));
    return new PVector(x, y);
  }
}

// Step 11: a hypotrochoid
class Hypotrochoid extends Shape {
  int R;
  int r;
  float d;

  Hypotrochoid(int R, int r, float d) {
    this.R = R;
    this.r = r;
    this.d = d;
  }

  PVector point(float theta) {
    float zoom = 1 / (abs(R - r) + d);   // so it reaches 1
    float x = zoom * ((R - r) * cos(theta) + d * cos((R - r) * theta / r));
    float y = zoom * ((R - r) * sin(theta) - d * sin((R - r) * theta / r));
    return new PVector(x, y);
  }

  // R / r in lowest terms. The bottom number is the trips
  int trips() {
    return r / greatestCommonDivisor(R, r);
  }
}

// Step 13: a Lissajous curve, as wide as it is tall
class Lissajous extends Shape {
  int a;
  int b;
  float delta;

  Lissajous(int a, int b, float delta) {
    this.a = a;
    this.b = b;
    this.delta = delta;
  }

  PVector point(float theta) {
    float x = sin(a * theta + delta);
    float y = sin(b * theta);
    return new PVector(x, y);
  }
}

// The biggest whole number that divides both numbers
int greatestCommonDivisor(int first, int second) {
  while (second != 0) {
    int remainder = first % second;
    first = second;
    second = remainder;
  }
  return first;
}
