/* ===========================================================
   STEP 15 — TWO SHAPES
   ===========================================================

   In Steps 2 to 14, both points went around the same shape.
   Now there are two shapes, both centered on the page, and
   they can overlap. Point one goes around the first shape,
   and point two goes around the second shape. Everything
   else is the same: join the two points with a line, pick
   a random spot on the line, and count it.

   Each shape is picked in one line, near the top:

       Shape shapeOne = new Rose(2);

   The shapes are the ones from Steps 5, 7, 9, 11 and 13, and
   the numbers in the brackets are that shape's values. Both
   points can go around the same kind of shape.

   Press PLAY. You should get a flower and a five-pointed
   star woven together.

   Step 16 is an animation of this step.

   THE VALUES YOU CAN CHANGE

     shapeOne          the shape point one goes around
     shapeTwo          the shape point two goes around
     shapeOneSize      how big shape one is. 1 is as big as
                       fits on the page
     shapeTwoSize      how big shape two is
     pointOneSpeed     how many times point one goes around
     pointTwoSpeed     how many times point two goes around
     numberOfSamples   how many random spots to pick. More
                       samples make a smoother picture, but
                       take longer
     dotsPerInch       how sharp the picture is
     paperColor        the color of the paper
     primaryColor      the color where the most spots land

   THE EQUATIONS

   The equation for each shape is in its own step: rose in
   Step 5, square in Step 7, lemniscate in Step 9,
   hypotrochoid in Step 11 and Lissajous in Step 13.

   A point on the line between point one and point two:

       x = (1 - u) * pointOne.x + u * pointTwo.x
       y = (1 - u) * pointOne.y + u * pointTwo.y

         u = how far along the line, from 0 (at point one)
             to 1 (at point two)

   =========================================================== */

import processing.pdf.*;

// ---------- THE PAGE ------------------------------------
int pageWidth = 612;     // 8.5 inches when printed
int pageHeight = 792;    // 11 inches when printed
float pageMargin = 72 / 4.0;   // a quarter inch when printed

int dotsPerInch = 100;   // how many pixels per inch in the picture

// ---------- THE SHAPES ----------------------------------
// Pick a shape for each point. The choices are:
//
//   new Rose(k)                  k sets the petals, as in Step 5
//   new Square(rotation)         rotation turns it, as in Step 7
//   new Lemniscate()             a sideways figure eight, Step 9
//   new Hypotrochoid(R, r, d)    rolling circles, as in Step 11
//   new Lissajous(a, b, delta)   swings, as in Step 13
//
// Both points can go around the same kind of shape.

Shape shapeOne = new Rose(2);                 // point one goes around this
Shape shapeTwo = new Hypotrochoid(5, 3, 2);   // point two goes around this

float shapeOneSize = 1.0;   // 1 is as big as fits on the page
float shapeTwoSize = 1.0;   // 0.5 is half as big

int pointOneSpeed = 1;   // how many times point one goes around
int pointTwoSpeed = 2;   // how many times point two goes around

int numberOfSamples = 10000000;   // how many random spots to pick

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);   // white
color primaryColor = color( 30,  60, 140);   // navy

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
float centerX = pageWidth / 2;
float centerY = pageHeight / 2;

// how far a shape of size 1 reaches from the center, as big
// as fits inside the margins
float shapeRadius = min(pageWidth, pageHeight) / 2 - pageMargin;

// how many trips around it takes for both shapes to close
int trips = shapeOne.trips() * shapeTwo.trips();

// the picture's size in pixels. There are 72 points in an inch
float pixelsPerPoint = dotsPerInch / 72.0;
int pictureWidth = round(pageWidth * pixelsPerPoint);
int pictureHeight = round(pageHeight * pixelsPerPoint);

// how many times each pixel was picked
int[] counts = new int[pictureWidth * pictureHeight];

// ---------- THE DRAWING ---------------------------------
// as many threads as the CPU can run at once
int numberOfThreads = Runtime.getRuntime().availableProcessors();

void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);   // keeps the PDF the same size as the window
}

void setup() {
  noLoop();   // draw once, then wait
}

void draw() {
  int startTime = millis();

  // start the threads, each with its share of the samples
  SampleThread[] threads = new SampleThread[numberOfThreads];
  for (int threadNumber = 0; threadNumber < numberOfThreads; threadNumber++) {
    threads[threadNumber] = new SampleThread(numberOfSamples / numberOfThreads);
    threads[threadNumber].start();
  }

  // wait for every thread to finish, then add its counts in
  for (int threadNumber = 0; threadNumber < numberOfThreads; threadNumber++) {
    try {
      threads[threadNumber].join();
    } catch (InterruptedException error) {
      println("A thread was stopped early");
    }
    for (int pixelNumber = 0; pixelNumber < counts.length; pixelNumber++) {
      counts[pixelNumber] += threads[threadNumber].counts[pixelNumber];
    }
  }

  println(numberOfThreads + " threads took " + (millis() - startTime) + " ms");

  // find the biggest count
  int biggestCount = 0;
  for (int pixelNumber = 0; pixelNumber < counts.length; pixelNumber++) {
    biggestCount = max(biggestCount, counts[pixelNumber]);
  }

  // color each pixel: paper where nothing landed, the line
  // color where the most landed, and in between for the rest
  PImage picture = createImage(pictureWidth, pictureHeight, RGB);
  picture.loadPixels();
  for (int pixelNumber = 0; pixelNumber < counts.length; pixelNumber++) {
    float darkness = log(1 + counts[pixelNumber]) / log(1 + biggestCount);
    picture.pixels[pixelNumber] = lerpColor(paperColor, primaryColor, darkness);
  }
  picture.updatePixels();

  beginRecord(PDF, "picture.pdf");
  image(picture, 0, 0, pageWidth, pageHeight);
  endRecord();
}

// One thread. It picks its own random spots and keeps its own
// counts, so it never has to wait for the other threads
class SampleThread extends Thread {
  int numberOfSamplesToPick;
  int[] counts = new int[pictureWidth * pictureHeight];
  java.util.Random randomNumbers = new java.util.Random();

  SampleThread(int numberOfSamplesToPick) {
    this.numberOfSamplesToPick = numberOfSamplesToPick;
  }

  public void run() {
    for (int sampleNumber = 0; sampleNumber < numberOfSamplesToPick; sampleNumber++) {
      float t = randomNumbers.nextFloat() * TWO_PI * trips;

      PVector pointOne = pointOneAt(t);
      PVector pointTwo = pointTwoAt(t);

      float u = randomNumbers.nextFloat();
      float x = (1 - u) * pointOne.x + u * pointTwo.x;
      float y = (1 - u) * pointOne.y + u * pointTwo.y;

      int column = round(x * pixelsPerPoint);
      int row = round(y * pixelsPerPoint);
      // skip spots that land off the page
      if (column >= 0 && column < pictureWidth && row >= 0 && row < pictureHeight) {
        counts[row * pictureWidth + column]++;
      }
    }
  }
}

// Where point one is at angle t
PVector pointOneAt(float t) {
  PVector point = shapeOne.point(t * pointOneSpeed);
  float x = centerX + shapeRadius * shapeOneSize * point.x;
  float y = centerY + shapeRadius * shapeOneSize * point.y;
  return new PVector(x, y);
}

// Where point two is at angle t
PVector pointTwoAt(float t) {
  PVector point = shapeTwo.point(t * pointTwoSpeed);
  float x = centerX + shapeRadius * shapeTwoSize * point.x;
  float y = centerY + shapeRadius * shapeTwoSize * point.y;
  return new PVector(x, y);
}

// ---------- THE SHAPES ----------------------------------
// Each shape says where its point is at angle theta. Every
// shape reaches 1 from its center, and pointOneAt() and
// pointTwoAt() make it bigger to fit the page.

class Shape {
  PVector point(float theta) {
    return new PVector(0, 0);
  }

  // how many trips around before the shape closes
  int trips() {
    return 1;
  }
}

// Step 5: a rose
class Rose extends Shape {
  int k;

  Rose(int k) {
    this.k = k;
  }

  PVector point(float theta) {
    float x = cos(k * theta) * cos(theta);
    float y = cos(k * theta) * sin(theta);
    return new PVector(x, y);
  }
}

// Step 7: a square, 1 from the center to each side
class Square extends Shape {
  float rotation;

  Square(float rotation) {
    this.rotation = rotation;
  }

  PVector point(float theta) {
    // the same angle, moved into the range 0 up to TWO_PI
    float angle = theta % TWO_PI;
    if (angle < 0) {
      angle += TWO_PI;
    }

    // where a line from the center at this angle crosses the
    // edge of a square that reaches from -1 to 1
    float edgeX;
    float edgeY;
    if (angle >= QUARTER_PI && angle < 3 * QUARTER_PI) {
      edgeX = cos(angle) / sin(angle);   // the bottom edge
      edgeY = 1;
    } else if (angle >= 3 * QUARTER_PI && angle < 5 * QUARTER_PI) {
      edgeX = -1;                        // the left edge
      edgeY = -tan(angle);
    } else if (angle >= 5 * QUARTER_PI && angle < 7 * QUARTER_PI) {
      edgeX = -cos(angle) / sin(angle);  // the top edge
      edgeY = -1;
    } else {
      edgeX = 1;                         // the right edge
      edgeY = tan(angle);
    }

    // turn it by rotation
    float x = edgeX * cos(rotation) - edgeY * sin(rotation);
    float y = edgeY * cos(rotation) + edgeX * sin(rotation);
    return new PVector(x, y);
  }
}

// Step 9: a lemniscate
class Lemniscate extends Shape {
  PVector point(float theta) {
    float x = cos(theta) / (1 + sin(theta) * sin(theta));
    float y = sin(theta) * cos(theta) / (1 + sin(theta) * sin(theta));
    return new PVector(x, y);
  }
}

// Step 11: a hypotrochoid
class Hypotrochoid extends Shape {
  int R;
  int r;
  float d;

  Hypotrochoid(int R, int r, float d) {
    this.R = R;
    this.r = r;
    this.d = d;
  }

  PVector point(float theta) {
    float zoom = 1 / (abs(R - r) + d);   // so it reaches 1
    float x = zoom * ((R - r) * cos(theta) + d * cos((R - r) * theta / r));
    float y = zoom * ((R - r) * sin(theta) - d * sin((R - r) * theta / r));
    return new PVector(x, y);
  }

  // R / r in lowest terms. The bottom number is the trips
  int trips() {
    return r / greatestCommonDivisor(R, r);
  }
}

// Step 13: a Lissajous curve, as wide as it is tall
class Lissajous extends Shape {
  int a;
  int b;
  float delta;

  Lissajous(int a, int b, float delta) {
    this.a = a;
    this.b = b;
    this.delta = delta;
  }

  PVector point(float theta) {
    float x = sin(a * theta + delta);
    float y = sin(b * theta);
    return new PVector(x, y);
  }
}

// The biggest whole number that divides both numbers
int greatestCommonDivisor(int first, int second) {
  while (second != 0) {
    int remainder = first % second;
    first = second;
    second = remainder;
  }
  return first;
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     Shape shapeOne = new Rose(2);
     Shape shapeTwo = new Rose(3);       // two roses

     Shape shapeOne = new Square(0);
     Shape shapeTwo = new Square(QUARTER_PI);   // a square
     float shapeTwoSize = 0.7;                  // and a diamond

     Shape shapeOne = new Lemniscate();
     Shape shapeTwo = new Lissajous(3, 2, 0.785);
     int pointTwoSpeed = 1;

     float shapeOneSize = 0.5;   // a small rose in the middle

     int pointOneSpeed = 2;
     int pointTwoSpeed = 3;

   =========================================================== */
