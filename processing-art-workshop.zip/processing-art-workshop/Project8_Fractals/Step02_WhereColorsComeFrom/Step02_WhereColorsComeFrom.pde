/* ===========================================================
   STEP 2 — WHERE THE COLORS COME FROM
   ===========================================================

   Press PLAY and watch. This animation shows how Step 1
   decides the color of each spot.

   A point c is picked. z starts at 0, and each step it
   jumps to z * z + c. Its path is drawn as dots joined by
   lines. The gray circle is everything within 2 of 0: once
   z jumps outside it, z will always race off to infinity.

   When z leaves the circle, the spot c is colored by how
   many steps that took, the same way Step 1 does it. If z
   is still inside after maxSteps steps, c is counted as in
   the Mandelbrot set and gets insideColor.

   Then the next point is picked, and the next. Points are
   picked in a random order, without repeats, one square of
   the window at a time, so the Mandelbrot set slowly fills
   in. The first slowPoints points go slowly, so you can
   follow and talk through each jump. At least
   setPointsAtStart of them are in the set, so you can see
   what that looks like. Then it speeds up until whole paths
   flash by. When every square is colored, it waits, then
   starts over.

   THE VALUES YOU CAN CHANGE

     windowMargin      the space around the circle. The
                       circle fills the window inside it
     maxSteps          how many steps to try before deciding
                       z stays small
     markSize          how big each colored square is
     firstFramesPerStep  how many frames each jump takes at
                       the start
     fastestStepsPerFrame  how many jumps happen each frame
                       once it is up to speed
     slowPoints        how many points go at the slow speed
                       before it starts to speed up
     setPointsAtStart  how many of the slow points are sure
                       to be in the set
     pointsToSpeedUp   how many points it takes to get up to
                       speed after that
     pauseSteps        how long to wait after each point, in
                       jumps
     framesHolding     how many frames the finished picture
                       stays before starting over
     paperColor        the color of the paper
     edgeColor         the color near the edge of the set
     insideColor       the color of the set
     lineColor         the color of the path
     pointColor        the color of the point c
     circleColor       the color of the circle
     textColor         the color of the words

   THE EQUATIONS

   From Step 1. With z = x + y*i and c = cx + cy*i:

       newX = x * x - y * y + cx
       newY = 2 * x * y + cy

   z has left the circle when:

       x * x + y * y > 4

   The color of c, if z left the circle after steps steps:

       fraction = log(1 + steps) / log(1 + maxSteps)
       color = lerpColor(paperColor, edgeColor, fraction)

   The speed, in jumps per frame, grows evenly by
   multiplying, from 1 / firstFramesPerStep to
   fastestStepsPerFrame:

       along = (pointsDone - slowPoints) / pointsToSpeedUp

   kept between 0 and 1, and then:

       speed = firstSpeed * (fastestStepsPerFrame / firstSpeed) ^ along

   =========================================================== */

// ---------- THE WINDOW ----------------------------------
int windowWidth = 800;
int windowHeight = 800;
float windowMargin = 18;

// ---------- THE VIEW ------------------------------------
int maxSteps = 50;
float markSize = 4;

// ---------- THE TIMING ----------------------------------
float firstFramesPerStep = 30;
float fastestStepsPerFrame = 200;
int slowPoints = 10;
int setPointsAtStart = 2;
int pointsToSpeedUp = 30;
int pauseSteps = 6;
int framesHolding = 300;

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);   // white
color edgeColor = color(  0, 130, 200);   // azure, from Step 1
color insideColor = color( 20,  15,  40);   // midnight, from Step 1
color lineColor = color(  0, 150, 110);   // jade
color pointColor = color(230,  60, 140);   // hot pink
color circleColor = color(150, 150, 150);
color textColor = color(0, 0, 0);

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
// the picture fills the window inside the margins
float pictureWidthInWindow = windowWidth - 2 * windowMargin;
float pictureHeightInWindow = windowHeight - 2 * windowMargin;

// The view is centered on 0, and sized so the circle, 4
// across, just fits inside the margins. The longer side of
// the window shows more, so nothing is stretched
float viewCenterX = 0;
float viewCenterY = 0;
float viewWidth = 4 * pictureWidthInWindow / min(pictureWidthInWindow, pictureHeightInWindow);
float viewHeight = 4 * pictureHeightInWindow / min(pictureWidthInWindow, pictureHeightInWindow);

// the squares that get colored, one for each point c
int markColumns = floor(pictureWidthInWindow / markSize);
int markRows = floor(pictureHeightInWindow / markSize);
int numberOfMarks = markColumns * markRows;

float firstSpeed = 1 / firstFramesPerStep;

// ---------- THE DRAWING ---------------------------------
PGraphics markLayer;   // the colored squares, kept between
                       // frames

int[] markOrder = new int[numberOfMarks];   // the squares, in a
                                            // random order
int pointsDone;

// the point c being worked on, and z's path so far
float cx;
float cy;
float[] pathX = new float[maxSteps + 1];
float[] pathY = new float[maxSteps + 1];
int steps;
boolean hasEscaped;
int pauseLeft;
int holdLeft;

float jumpsOwed = 0;   // jumps the speed has earned but that
                       // haven't happened yet

void settings() {
  size(windowWidth, windowHeight, P2D);
  pixelDensity(1);
  smooth(8);
}

void setup() {
  markLayer = createGraphics(windowWidth, windowHeight, P2D);
  startOver();
}

// Clears the colored squares and shuffles the order to color
// them in
void startOver() {
  markLayer.beginDraw();
  markLayer.clear();
  markLayer.endDraw();

  for (int markNumber = 0; markNumber < numberOfMarks; markNumber++) {
    markOrder[markNumber] = markNumber;
  }
  for (int markNumber = numberOfMarks - 1; markNumber > 0; markNumber--) {
    int other = int(random(markNumber + 1));
    int saved = markOrder[markNumber];
    markOrder[markNumber] = markOrder[other];
    markOrder[other] = saved;
  }
  putSetPointsEarly();

  pointsDone = 0;
  holdLeft = 0;
  startPoint();
}

// Makes sure at least setPointsAtStart of the slow points at
// the start are in the set, by swapping in-set squares from
// later in the order into random early spots
void putSetPointsEarly() {
  int setPointsEarly = 0;
  for (int orderNumber = 0; orderNumber < slowPoints; orderNumber++) {
    if (isInSet(markOrder[orderNumber])) {
      setPointsEarly++;
    }
  }
  int wanted = min(setPointsAtStart, slowPoints);
  for (int later = slowPoints; later < numberOfMarks && setPointsEarly < wanted; later++) {
    if (isInSet(markOrder[later])) {
      int early = int(random(slowPoints));
      while (isInSet(markOrder[early])) {
        early = int(random(slowPoints));
      }
      int saved = markOrder[early];
      markOrder[early] = markOrder[later];
      markOrder[later] = saved;
      setPointsEarly++;
    }
  }
}

// true if z stays in the circle for maxSteps steps when c is
// the middle of this square
boolean isInSet(int markNumber) {
  float cx = markCx(markNumber);
  float cy = markCy(markNumber);
  float x = 0;
  float y = 0;
  for (int stepNumber = 0; stepNumber < maxSteps; stepNumber++) {
    float newX = x * x - y * y + cx;
    float newY = 2 * x * y + cy;
    x = newX;
    y = newY;
    if (x * x + y * y > 4) {
      return false;
    }
  }
  return true;
}

// The point c in the middle of a square
float markCx(int markNumber) {
  int column = markNumber % markColumns;
  return viewCenterX + viewWidth * ((column + 0.5) / markColumns - 0.5);
}

float markCy(int markNumber) {
  int row = markNumber / markColumns;
  return viewCenterY - viewHeight * ((row + 0.5) / markRows - 0.5);
}

// Picks the next point c: the middle of the next square
void startPoint() {
  cx = markCx(markOrder[pointsDone]);
  cy = markCy(markOrder[pointsDone]);

  pathX[0] = 0;
  pathY[0] = 0;
  steps = 0;
  hasEscaped = false;
  pauseLeft = pauseSteps;
}

void draw() {
  if (holdLeft > 0) {
    // the finished picture stays a while
    holdLeft--;
    if (holdLeft == 0) {
      startOver();
    }
  } else {
    float along = constrain((pointsDone - slowPoints) / (float) pointsToSpeedUp, 0, 1);
    float speed = firstSpeed * pow(fastestStepsPerFrame / firstSpeed, along);
    jumpsOwed += speed;
    while (jumpsOwed >= 1 && holdLeft == 0) {
      jumpsOwed--;
      takeOneJump();
    }
  }

  background(paperColor);
  image(markLayer, 0, 0);

  // the path, kept inside the margins
  clip(windowMargin, windowMargin, pictureWidthInWindow, pictureHeightInWindow);

  noFill();
  stroke(circleColor);
  strokeWeight(1);
  float circleSize = 4 * pictureWidthInWindow / viewWidth;
  circle(windowXOf(0), windowYOf(0), circleSize);

  if (holdLeft == 0) {
    stroke(lineColor);
    strokeWeight(2);
    for (int stepNumber = 1; stepNumber <= steps; stepNumber++) {
      line(windowXOf(pathX[stepNumber - 1]), windowYOf(pathY[stepNumber - 1]),
           windowXOf(pathX[stepNumber]), windowYOf(pathY[stepNumber]));
    }
    noStroke();
    fill(lineColor);
    for (int stepNumber = 0; stepNumber <= steps; stepNumber++) {
      circle(windowXOf(pathX[stepNumber]), windowYOf(pathY[stepNumber]), 6);
    }

    // the point c, as a ring around its square
    noFill();
    stroke(pointColor);
    strokeWeight(3);
    circle(windowXOf(cx), windowYOf(cy), 14);
  }

  noClip();

  // what is happening, in words
  String saying;
  if (holdLeft > 0) {
    saying = "Every square is colored. Starting over soon.";
  } else if (hasEscaped) {
    saying = "z left the circle after " + steps + " steps, so c gets that color.";
  } else if (steps == maxSteps) {
    saying = "z stayed in the circle for all " + maxSteps + " steps, so c is in the set.";
  } else {
    float distance = sqrt(pathX[steps] * pathX[steps] + pathY[steps] * pathY[steps]);
    saying = "Step " + steps + ": z is " + nf(distance, 1, 2) + " away from 0.";
  }
  // c written as cx + cy*i, or cx - cy*i when cy is negative
  String plusOrMinus = " + ";
  if (cy < 0) {
    plusOrMinus = " - ";
  }
  fill(textColor);
  textSize(12);
  text("c = " + nf(cx, 1, 3) + plusOrMinus + nf(abs(cy), 1, 3) + "i      " + saying,
       windowMargin, windowHeight - 4);
}

// One jump of z, or one jump's worth of waiting after z is
// done
void takeOneJump() {
  boolean isDone = hasEscaped || steps == maxSteps;
  if (!isDone) {
    float x = pathX[steps];
    float y = pathY[steps];
    float newX = x * x - y * y + cx;
    float newY = 2 * x * y + cy;
    steps++;
    pathX[steps] = newX;
    pathY[steps] = newY;
    hasEscaped = newX * newX + newY * newY > 4;
    if (hasEscaped || steps == maxSteps) {
      colorMark();
    }
  } else if (pauseLeft > 0) {
    pauseLeft--;
  } else {
    pointsDone++;
    if (pointsDone == numberOfMarks) {
      holdLeft = framesHolding;
    } else {
      startPoint();
    }
  }
}

// Colors c's square, the same way Step 1 colors its pixel
void colorMark() {
  color markColor;
  if (hasEscaped) {
    float fraction = log(1 + steps) / log(1 + maxSteps);
    markColor = lerpColor(paperColor, edgeColor, fraction);
  } else {
    markColor = insideColor;
  }
  markLayer.beginDraw();
  markLayer.noStroke();
  markLayer.fill(markColor);
  markLayer.rectMode(CENTER);
  markLayer.rect(windowXOf(cx), windowYOf(cy), markSize, markSize);
  markLayer.endDraw();
}

// Where the equation's x and y are in the window. y goes up
// in the equations but down the window, so it is subtracted
float windowXOf(float x) {
  return windowMargin + pictureWidthInWindow * ((x - viewCenterX) / viewWidth + 0.5);
}

float windowYOf(float y) {
  return windowMargin + pictureHeightInWindow * (0.5 - (y - viewCenterY) / viewHeight);
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     int slowPoints = 20;            // stays slow longer

     float markSize = 3;             // a sharper picture that
                                     // takes longer to fill

     int maxSteps = 5;               // too few steps: a blobby
                                     // set, like Step 1 with
                                     // maxSteps = 10

     float windowMargin = 100;       // a smaller circle with
                                     // room around it

   =========================================================== */
