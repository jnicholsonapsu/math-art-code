/* ===========================================================
   STEP 5 — THE BUDDHABROT
   ===========================================================

   The Buddhabrot uses the Mandelbrot set's step, but it
   draws something different. Step 1 colored each point c by
   how long z took to escape. The Buddhabrot instead draws
   where z goes on its way out.

   Lots of points c are picked at random. For each one, z
   starts at 0 and steps along as in Step 1. If z escapes,
   every spot it landed on gets one more visit counted. Spots
   visited often are drawn dark, and spots rarely visited are
   drawn light. Points c whose z never escapes are skipped,
   and so are ones that escape in fewer than minSteps steps,
   since their short paths only add a fuzzy haze.

   The technique was found in 1993 by Melinda Green, a
   software developer and computer artist. The picture is
   turned on its side, with x running down the page, and
   then it looks like a seated Buddha, which gave it its
   name.

   Millions of paths are followed, so the work is split
   between threads, as in Project 3 Step 4. Each thread
   follows its own share of the paths and keeps its own
   counts, and the counts are added up at the end.

   Press PLAY. The console at the bottom of the Processing
   window says how many threads were used and how long it
   took. The picture is also saved as picture.pdf.

   THE VALUES YOU CAN CHANGE

     numberOfSamples   how many points c to try. More makes a
                       smoother picture but takes longer
     maxSteps          the longest path counted. Paths longer
                       than this count as never escaping
     minSteps          the shortest path counted
     viewCenterX,
     viewCenterY       the point in the middle of the picture
     viewLength        how much of x fits from the top of the
                       picture to the bottom
     dotsPerInch       how many pixels per inch in the picture
     paperColor        the color of the paper
     pointColor        the color of the most visited spots

   THE EQUATIONS

   The step from Step 1. With z = x + y*i and c = cx + cy*i:

       newX = x * x - y * y + cx
       newY = 2 * x * y + cy

   until:

       x * x + y * y > 4

   c is picked at random, with cx from -2 to 1 and cy from
   -1.5 to 1.5, which holds the whole Mandelbrot set.

   How dark each spot is, from how many visits it got:

       darkness = sqrt(visits / mostVisits)
       color = lerpColor(paperColor, pointColor, darkness)

   The square root makes the rarely visited spots darker, so
   the faint parts show.

   =========================================================== */

import processing.pdf.*;

// ---------- THE PAGE ------------------------------------
int pageWidth = 612;     // 8.5 inches when printed
int pageHeight = 792;    // 11 inches when printed
float pageMargin = 72 / 4.0;   // a quarter inch when printed

int dotsPerInch = 100;   // how many pixels per inch in the picture

// ---------- THE PATHS -----------------------------------
int numberOfSamples = 10000000;
int maxSteps = 1000;
int minSteps = 20;

// ---------- THE VIEW ------------------------------------
float viewCenterX = -0.45;
float viewCenterY = 0;
float viewLength = 3.2;

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);   // white
color pointColor = color( 40,  40, 110);   // dark indigo

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
// the picture fills the page inside the margins
float pictureWidthOnPage = pageWidth - 2 * pageMargin;
float pictureHeightOnPage = pageHeight - 2 * pageMargin;

// the picture's size in pixels. There are 72 points in an inch
float pixelsPerPoint = dotsPerInch / 72.0;
int pictureWidth = round(pictureWidthOnPage * pixelsPerPoint);
int pictureHeight = round(pictureHeightOnPage * pixelsPerPoint);

// x runs down the picture, and y runs across it. The view is
// as wide as it needs to be to match the picture's shape, so
// nothing is stretched
float viewBreadth = viewLength * pictureWidth / pictureHeight;
float viewTop = viewCenterX - viewLength / 2;
float viewLeft = viewCenterY - viewBreadth / 2;

// ---------- THE DRAWING ---------------------------------
// as many threads as the CPU can run at once
int numberOfThreads = Runtime.getRuntime().availableProcessors();

void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);   // keeps the PDF the same size as the window
}

void setup() {
  noLoop();   // draw once, then wait
}

void draw() {
  int startTime = millis();

  // start the threads, each with its share of the samples
  PathThread[] threads = new PathThread[numberOfThreads];
  for (int threadNumber = 0; threadNumber < numberOfThreads; threadNumber++) {
    threads[threadNumber] = new PathThread(numberOfSamples / numberOfThreads);
    threads[threadNumber].start();
  }

  // wait for every thread to finish, then add its visits in
  int[] visits = new int[pictureWidth * pictureHeight];
  for (int threadNumber = 0; threadNumber < numberOfThreads; threadNumber++) {
    try {
      threads[threadNumber].join();
    } catch (InterruptedException error) {
      println("A thread was stopped early");
    }
    for (int pixelNumber = 0; pixelNumber < visits.length; pixelNumber++) {
      visits[pixelNumber] += threads[threadNumber].visits[pixelNumber];
    }
  }

  println(numberOfThreads + " threads took " + (millis() - startTime) + " ms");

  int mostVisits = max(1, max(visits));

  PImage picture = createImage(pictureWidth, pictureHeight, RGB);
  picture.loadPixels();
  for (int pixelNumber = 0; pixelNumber < visits.length; pixelNumber++) {
    float darkness = sqrt(visits[pixelNumber] / (float) mostVisits);
    picture.pixels[pixelNumber] = lerpColor(paperColor, pointColor, darkness);
  }
  picture.updatePixels();

  beginRecord(PDF, "picture.pdf");
  background(paperColor);
  image(picture, pageMargin, pageMargin, pictureWidthOnPage, pictureHeightOnPage);
  endRecord();
}

// One thread. It picks its own points c and keeps its own
// visits, so it never has to wait for the other threads
class PathThread extends Thread {
  int numberOfSamplesToPick;
  int[] visits = new int[pictureWidth * pictureHeight];
  float[] pathX = new float[maxSteps];
  float[] pathY = new float[maxSteps];
  java.util.Random randomNumbers = new java.util.Random();

  PathThread(int numberOfSamplesToPick) {
    this.numberOfSamplesToPick = numberOfSamplesToPick;
  }

  public void run() {
    for (int sampleNumber = 0; sampleNumber < numberOfSamplesToPick; sampleNumber++) {
      // cx from -2 to 1, and cy from -1.5 to 1.5
      float cx = -2 + 3 * randomNumbers.nextFloat();
      float cy = -1.5 + 3 * randomNumbers.nextFloat();

      // step z, remembering where it lands
      float x = 0;
      float y = 0;
      int steps = 0;
      while (steps < maxSteps && x * x + y * y <= 4) {
        float newX = x * x - y * y + cx;
        float newY = 2 * x * y + cy;
        x = newX;
        y = newY;
        pathX[steps] = x;
        pathY[steps] = y;
        steps++;
      }

      // if z escaped after at least minSteps steps, count a
      // visit at every spot on its path that is in the picture
      boolean hasEscaped = x * x + y * y > 4;
      if (hasEscaped && steps >= minSteps) {
        for (int stepNumber = 0; stepNumber < steps; stepNumber++) {
          int row = floor((pathX[stepNumber] - viewTop) / viewLength * pictureHeight);
          int column = floor((pathY[stepNumber] - viewLeft) / viewBreadth * pictureWidth);
          if (row >= 0 && row < pictureHeight && column >= 0 && column < pictureWidth) {
            visits[row * pictureWidth + column]++;
          }
        }
      }
    }
  }
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     int numberOfSamples = 1000000;   // quicker, but grainy

     int maxSteps = 100;              // only short paths: a
     int minSteps = 1;                // soft, ghostly shape

     int minSteps = 1;                // every escaping path,
                                      // with a haze around it

     int maxSteps = 20000;            // only very long paths:
     int minSteps = 1000;             // thin, sharp threads.
     int numberOfSamples = 50000000;  // Few paths are this
                                      // long, so it needs
                                      // many more samples

   =========================================================== */
