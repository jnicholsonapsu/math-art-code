/* ===========================================================
   STEP 4 — THE MANDELBROT SET AND JULIA SETS TOGETHER
   ===========================================================

   Press PLAY. Two windows open. One shows the Mandelbrot set
   from Step 1. The other shows the Julia set from Step 3 for
   the point c under the mouse in the Mandelbrot window. Move
   the mouse around the Mandelbrot set and watch the Julia
   set change.

   Each point of the Mandelbrot window is a value of c, so
   the Mandelbrot set is like a map of all the Julia sets:

     Inside the Mandelbrot set, the Julia set is one
     connected piece, with an inside.

     Outside it, the Julia set breaks apart into dust.

     Near the edge, the Julia set is the most detailed, and it
     often looks like the part of the edge the mouse is on.

   Click in the Mandelbrot window to keep c where it is, so
   you can move the mouse away. Click again to let it follow
   the mouse.

   THE VALUES YOU CAN CHANGE

     windowSize               the width and height of each
                              window
     mandelbrotCenterX,
     mandelbrotCenterY        the point in the middle of the
                              Mandelbrot window
     mandelbrotViewWidth      how wide the Mandelbrot window is,
                              in the equation's numbers
     juliaViewWidth           how wide the Julia window is
     maxSteps                 how many steps to try before
                              deciding z stays small. More is
                              sharper but slower to follow the
                              mouse
     paperColor               the color of the paper
     mandelbrotEdgeColor,
     mandelbrotInsideColor    the Mandelbrot set's colors
     juliaEdgeColor,
     juliaInsideColor         the Julia set's colors
     pointColor               the color of the mark at c
     textColor                the color of the words

   THE EQUATIONS

   Both use Step 1's step. With z = x + y*i and c = cx + cy*i:

       newX = x * x - y * y + cx
       newY = 2 * x * y + cy

   until:

       x * x + y * y > 4

   Mandelbrot window: z starts at 0, and c is the pixel's
   point.

   Julia window: z starts at the pixel's point, and c is the
   point under the mouse in the Mandelbrot window.

   The color outside each set:

       fraction = log(1 + steps) / log(1 + maxSteps)
       color = lerpColor(paperColor, edgeColor, fraction)

   =========================================================== */

// ---------- THE WINDOWS ---------------------------------
int windowSize = 500;   // both windows are this wide and tall

// ---------- THE VIEWS -----------------------------------
float mandelbrotCenterX = -0.75;
float mandelbrotCenterY = 0;
float mandelbrotViewWidth = 3;
float juliaViewWidth = 3.6;

int maxSteps = 100;

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);   // white
color mandelbrotEdgeColor = color(  0, 130, 200);   // azure, from Step 1
color mandelbrotInsideColor = color( 20,  15,  40);   // midnight, from Step 1
color juliaEdgeColor = color(110,  30, 160);   // violet, from Step 3
color juliaInsideColor = color( 35,  10,  20);   // dark wine, from Step 3
color pointColor = color(255,  40,  40);   // bright red
color textColor = color(0, 0, 0);

// ---------- THE DRAWING ---------------------------------
PImage mandelbrotPicture;

// the point c the Julia set uses
float cx = -0.8;
float cy = 0.156;
boolean isKept = false;   // true when a click keeps c where
                          // it is

JuliaWindow juliaWindow;

// Both windows use Processing's plain renderer, not P2D.
// Different renderers handle screen scaling differently, so
// mixing them can make the windows come out different sizes,
// and two P2D windows at once can be troublesome
void settings() {
  size(windowSize, windowSize);
  pixelDensity(1);
}

void setup() {
  surface.setTitle("Mandelbrot set: move the mouse");

  // the Mandelbrot set never changes, so it is drawn once
  mandelbrotPicture = createImage(windowSize, windowSize, RGB);
  mandelbrotPicture.loadPixels();
  for (int row = 0; row < windowSize; row++) {
    for (int column = 0; column < windowSize; column++) {
      float pixelCx = mandelbrotXOf(column);
      float pixelCy = mandelbrotYOf(row);
      int steps = stepsToEscape(0, 0, pixelCx, pixelCy);
      mandelbrotPicture.pixels[row * windowSize + column] =
        colorFor(steps, mandelbrotEdgeColor, mandelbrotInsideColor);
    }
  }
  mandelbrotPicture.updatePixels();

  // open the second window
  juliaWindow = new JuliaWindow();
  PApplet.runSketch(new String[] {"Julia set"}, juliaWindow);
}

void draw() {
  // c follows the mouse, unless a click is keeping it
  if (!isKept) {
    cx = mandelbrotXOf(mouseX);
    cy = mandelbrotYOf(mouseY);
  }

  image(mandelbrotPicture, 0, 0);

  // a cross at c
  float crossX = (cx - mandelbrotCenterX) / mandelbrotViewWidth * windowSize
               + windowSize / 2.0;
  float crossY = (mandelbrotCenterY - cy) / mandelbrotViewWidth * windowSize
               + windowSize / 2.0;
  stroke(pointColor);
  strokeWeight(2);
  line(crossX - 8, crossY, crossX + 8, crossY);
  line(crossX, crossY - 8, crossX, crossY + 8);
}

void mousePressed() {
  isKept = !isKept;
}

// The point c for a column or row of the Mandelbrot window.
// The window is square, so the view is as tall as it is wide.
// y goes up in the equations but down the rows, so it is
// subtracted
float mandelbrotXOf(float column) {
  return mandelbrotCenterX + mandelbrotViewWidth * ((column + 0.5) / windowSize - 0.5);
}

float mandelbrotYOf(float row) {
  return mandelbrotCenterY - mandelbrotViewWidth * ((row + 0.5) / windowSize - 0.5);
}

// How many steps z takes to get more than 2 away from 0,
// starting at x, y, with the point c at cx, cy. maxSteps
// means it never did
int stepsToEscape(float x, float y, float cx, float cy) {
  int steps = 0;
  while (steps < maxSteps && x * x + y * y <= 4) {
    float newX = x * x - y * y + cx;
    float newY = 2 * x * y + cy;
    x = newX;
    y = newY;
    steps++;
  }
  return steps;
}

// The color for a number of steps, the same way Step 1 does it
color colorFor(int steps, color edgeColor, color insideColor) {
  if (steps == maxSteps) {
    return insideColor;
  }
  float fraction = log(1 + steps) / log(1 + maxSteps);
  return lerpColor(paperColor, edgeColor, fraction);
}

// The second window. It is a sketch of its own, with its own
// settings, setup and draw, but it can use everything above
class JuliaWindow extends PApplet {
  PImage juliaPicture;
  float drawnCx;   // the c the picture was last drawn for
  float drawnCy;

  void settings() {
    size(windowSize, windowSize);
    pixelDensity(1);
  }

  void setup() {
    juliaPicture = createImage(windowSize, windowSize, RGB);
    drawnCx = Float.NaN;   // so the first frame draws it
  }

  void draw() {
    // only draw the Julia set again when c has moved
    if (cx != drawnCx || cy != drawnCy) {
      drawnCx = cx;
      drawnCy = cy;
      juliaPicture.loadPixels();
      for (int row = 0; row < windowSize; row++) {
        for (int column = 0; column < windowSize; column++) {
          // z starts at this pixel's point, around 0
          float x = juliaViewWidth * ((column + 0.5) / windowSize - 0.5);
          float y = -juliaViewWidth * ((row + 0.5) / windowSize - 0.5);
          int steps = stepsToEscape(x, y, drawnCx, drawnCy);
          juliaPicture.pixels[row * windowSize + column] =
            colorFor(steps, juliaEdgeColor, juliaInsideColor);
        }
      }
      juliaPicture.updatePixels();
    }

    image(juliaPicture, 0, 0);

    // c written as cx + cy*i, or cx - cy*i when cy is negative
    String plusOrMinus = " + ";
    if (drawnCy < 0) {
      plusOrMinus = " - ";
    }
    String saying = "c = " + nf(drawnCx, 1, 3) + plusOrMinus + nf(abs(drawnCy), 1, 3) + "i";
    if (isKept) {
      saying += "   (kept: click the Mandelbrot window to follow the mouse)";
    }
    fill(textColor);
    textSize(12);
    text(saying, 8, windowSize - 8);
  }
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     int maxSteps = 30;           // follows the mouse faster,
                                  // but blurrier

     float mandelbrotCenterX = -0.75;   // zoomed in on Seahorse
     float mandelbrotCenterY = 0.1;     // Valley
     float mandelbrotViewWidth = 0.3;

     int windowSize = 300;        // smaller windows: the Julia
                                  // set keeps up better

   =========================================================== */
