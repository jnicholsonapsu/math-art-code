/* ===========================================================
   STEP 6 — THE NEBULABROT
   ===========================================================

   In Step 5, the length of the paths that are counted
   changes the picture. Short paths make a soft cloud, and
   long paths make thin, sharp threads.

   Melinda Green made her color pictures by drawing the
   Buddhabrot several times with a different maxSteps each
   time, and putting each one in its own color channel, the
   same way astronomers make color pictures of space. This
   sketch uses the same idea with three channels. In hers,
   each picture counted every path up to its maxSteps. Here,
   unless useGreenApproach is true, each path goes to only
   one channel, by how many steps z took to escape:

     short    from minSteps to shortMaxSteps steps
     medium   from shortMaxSteps to mediumMaxSteps steps
     long     from mediumMaxSteps to longMaxSteps steps

   Each channel is drawn in its own color of light on black
   paper: red, green or blue. Where channels overlap, the
   lights add up, as on a screen: red and green make yellow,
   and all three make white. Pictures made this way are
   called Nebulabrots, since they look like nebulas, the
   glowing clouds of gas in space.

   A few spots get far more visits than the rest. If the most
   visited spot set the brightest shade, everything else would
   look dim, so the brightest shade is set by the spots in the
   top brightestShare of visits instead.

   The first points of a path are c itself and the point one
   step later. Paths are kept or dropped by their length, so
   these points would stamp the sharp outline of the kept
   area of c onto the picture. Skipping the first
   pointsToSkip points of each path keeps the picture smooth.

   Press PLAY. The console at the bottom of the Processing
   window says how many threads were used and how long it
   took. The picture is also saved as picture.pdf.

   THE VALUES YOU CAN CHANGE

     numberOfSamples   how many points c to try
     minSteps          the shortest path counted
     shortMaxSteps     the longest path in the short channel
     mediumMaxSteps    the longest path in the medium channel
     longMaxSteps      the longest path in the long channel
     pointsToSkip      how many points at the start of each
                       path are not counted
     useGreenApproach  false puts each path in one channel.
                       true counts it Melinda Green's way, in
                       its own channel and every longer one
     viewCenterX,
     viewCenterY       the point in the middle of the picture
     viewLength        how much of x fits from the top of the
                       picture to the bottom
     dotsPerInch       how many pixels per inch in the picture
     paperColor        the color of the paper
     shortColor        the color of the short channel
     mediumColor       the color of the medium channel
     longColor         the color of the long channel
     brightestShare      the share of each channel's spots
                       drawn in the full channel color

   THE EQUATIONS

   The step from Step 1. With z = x + y*i and c = cx + cy*i:

       newX = x * x - y * y + cx
       newY = 2 * x * y + cy

   until:

       x * x + y * y > 4

   How bright each channel is at a spot:

       brightness = visits / mostVisits
       shade = lerpColor(paperColor, channelColor, brightness)

   where mostVisits is the visits of the spot that has more
   visits than all but brightestShare of the spots. A spot with
   more visits than that is drawn with brightness 1.

   Adding the lights. Red, green and blue each go from 0 to
   255. For each of them:

       mixed = min(255, lightOne + lightTwo)

   =========================================================== */

import processing.pdf.*;

// ---------- THE PAGE ------------------------------------
int pageWidth = 612;     // 8.5 inches when printed
int pageHeight = 792;    // 11 inches when printed
float pageMargin = 72 / 4.0;   // a quarter inch when printed

int dotsPerInch = 100;   // how many pixels per inch in the picture

// ---------- THE PATHS -----------------------------------
int numberOfSamples = 20000000;
int minSteps = 5;
int shortMaxSteps = 50;
int mediumMaxSteps = 500;
int longMaxSteps = 5000;
int pointsToSkip = 2;
boolean useGreenApproach = false;   // true counts paths Melinda Green's way

// ---------- THE VIEW ------------------------------------
float viewCenterX = -0.45;
float viewCenterY = 0;
float viewLength = 3.2;

// ---------- THE LOOK ------------------------------------
color paperColor = color(  0,   0,   0);    // black
color shortColor = color(  0,   0, 255);    // blue
color mediumColor = color(  0, 255,   0);   // green
color longColor = color(255,   0,   0);     // red
float brightestShare = 0.01;   // one spot in a hundred

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
// the picture fills the page inside the margins
float pictureWidthOnPage = pageWidth - 2 * pageMargin;
float pictureHeightOnPage = pageHeight - 2 * pageMargin;

// the picture's size in pixels. There are 72 points in an inch
float pixelsPerPoint = dotsPerInch / 72.0;
int pictureWidth = round(pictureWidthOnPage * pixelsPerPoint);
int pictureHeight = round(pictureHeightOnPage * pixelsPerPoint);
int numberOfPixels = pictureWidth * pictureHeight;

// x runs down the picture, and y runs across it. The view is
// as wide as it needs to be to match the picture's shape, so
// nothing is stretched
float viewBreadth = viewLength * pictureWidth / pictureHeight;
float viewTop = viewCenterX - viewLength / 2;
float viewLeft = viewCenterY - viewBreadth / 2;

// the three channels, listed together so a loop can go
// through them: short is 0, medium is 1, and long is 2
int numberOfChannels = 3;
color[] channelColors = {shortColor, mediumColor, longColor};

// ---------- THE DRAWING ---------------------------------
// as many threads as the CPU can run at once
int numberOfThreads = Runtime.getRuntime().availableProcessors();

void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);   // keeps the PDF the same size as the window
}

void setup() {
  noLoop();   // draw once, then wait
}

void draw() {
  int startTime = millis();

  // start the threads, each with its share of the samples
  PathThread[] threads = new PathThread[numberOfThreads];
  for (int threadNumber = 0; threadNumber < numberOfThreads; threadNumber++) {
    threads[threadNumber] = new PathThread(numberOfSamples / numberOfThreads);
    threads[threadNumber].start();
  }

  // wait for every thread to finish, then add its visits in
  int[][] visits = new int[numberOfChannels][numberOfPixels];
  for (int threadNumber = 0; threadNumber < numberOfThreads; threadNumber++) {
    try {
      threads[threadNumber].join();
    } catch (InterruptedException error) {
      println("A thread was stopped early");
    }
    for (int channel = 0; channel < numberOfChannels; channel++) {
      for (int pixelNumber = 0; pixelNumber < numberOfPixels; pixelNumber++) {
        visits[channel][pixelNumber] += threads[threadNumber].visits[channel][pixelNumber];
      }
    }
  }

  println(numberOfThreads + " threads took " + (millis() - startTime) + " ms");

  // start with plain paper, then add in each channel's light
  PImage picture = createImage(pictureWidth, pictureHeight, RGB);
  picture.loadPixels();
  for (int pixelNumber = 0; pixelNumber < numberOfPixels; pixelNumber++) {
    picture.pixels[pixelNumber] = paperColor;
  }
  for (int channel = 0; channel < numberOfChannels; channel++) {
    // put the visits in order, and find the spot that has more
    // visits than all but brightestShare of the spots
    int[] sortedVisits = sort(visits[channel]);
    int brightestSpot = floor((1 - brightestShare) * (numberOfPixels - 1));
    int mostVisits = max(1, sortedVisits[brightestSpot]);

    for (int pixelNumber = 0; pixelNumber < numberOfPixels; pixelNumber++) {
      float brightness = min(1, visits[channel][pixelNumber] / (float) mostVisits);
      color shade = lerpColor(paperColor, channelColors[channel], brightness);
      picture.pixels[pixelNumber] = addLights(picture.pixels[pixelNumber], shade);
    }
  }
  picture.updatePixels();

  beginRecord(PDF, "picture.pdf");
  background(paperColor);
  image(picture, pageMargin, pageMargin, pictureWidthOnPage, pictureHeightOnPage);
  endRecord();
}

// Adds two colors of light, as two lamps shining on one spot
color addLights(color lightOne, color lightTwo) {
  float mixedRed = min(255, red(lightOne) + red(lightTwo));
  float mixedGreen = min(255, green(lightOne) + green(lightTwo));
  float mixedBlue = min(255, blue(lightOne) + blue(lightTwo));
  return color(mixedRed, mixedGreen, mixedBlue);
}

// One thread. It picks its own points c and keeps its own
// visits, so it never has to wait for the other threads
class PathThread extends Thread {
  int numberOfSamplesToPick;
  int[][] visits = new int[numberOfChannels][numberOfPixels];
  float[] pathX = new float[longMaxSteps];
  float[] pathY = new float[longMaxSteps];
  java.util.Random randomNumbers = new java.util.Random();

  PathThread(int numberOfSamplesToPick) {
    this.numberOfSamplesToPick = numberOfSamplesToPick;
  }

  public void run() {
    for (int sampleNumber = 0; sampleNumber < numberOfSamplesToPick; sampleNumber++) {
      // cx from -2 to 1, and cy from -1.5 to 1.5
      float cx = -2 + 3 * randomNumbers.nextFloat();
      float cy = -1.5 + 3 * randomNumbers.nextFloat();

      // step z, remembering where it lands
      float x = 0;
      float y = 0;
      int steps = 0;
      while (steps < longMaxSteps && x * x + y * y <= 4) {
        float newX = x * x - y * y + cx;
        float newY = 2 * x * y + cy;
        x = newX;
        y = newY;
        pathX[steps] = x;
        pathY[steps] = y;
        steps++;
      }

      // skip z if it never escaped, or escaped too soon
      boolean hasEscaped = x * x + y * y > 4;
      if (!hasEscaped || steps < minSteps) {
        continue;
      }

      // pick the channel by how long the path is
      int channel = 2;
      if (steps <= shortMaxSteps) {
        channel = 0;
      } else if (steps <= mediumMaxSteps) {
        channel = 1;
      }

      // count a visit at every spot on the path that is in
      // the picture, after the first pointsToSkip points
      for (int stepNumber = pointsToSkip; stepNumber < steps; stepNumber++) {
        int row = floor((pathX[stepNumber] - viewTop) / viewLength * pictureHeight);
        int column = floor((pathY[stepNumber] - viewLeft) / viewBreadth * pictureWidth);
        if (row >= 0 && row < pictureHeight && column >= 0 && column < pictureWidth) {
          if (useGreenApproach) {
            // Green's way: each channel counts every path up to
            // its own max steps, so a short path is counted by
            // its own channel and every longer one
            for (int countingChannel = channel; countingChannel < numberOfChannels; countingChannel++) {
              visits[countingChannel][row * pictureWidth + column]++;
            }
          } else {
            // each path is counted by its own channel only
            visits[channel][row * pictureWidth + column]++;
          }
        }
      }
    }
  }
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     float brightestShare = 0;      // the single most visited
                                    // spot sets the brightest
                                    // shade: much dimmer

     color shortColor = color(255,   0,   0);   // swap the
     color longColor = color(  0,   0, 255);    // short and
                                                // long colors

     int minSteps = 1;              // add the shortest paths:
                                    // a wide haze

     int mediumMaxSteps = 100;      // more paths go to the
                                    // long channel

     int numberOfSamples = 50000000;   // smoother, but slower

     int pointsToSkip = 0;          // sharp-edged blue wisps
                                    // around the outside

     boolean useGreenApproach = true;   // the short paths light
                                        // up all three channels,
                                        // and equal red, green
                                        // and blue make white:
                                        // a whiter picture with
                                        // a gray haze around it

   =========================================================== */
