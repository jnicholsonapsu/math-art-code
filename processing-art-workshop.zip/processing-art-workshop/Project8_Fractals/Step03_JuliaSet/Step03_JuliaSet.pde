/* ===========================================================
   STEP 3 — JULIA SETS
   ===========================================================

   Julia sets use the same step as the Mandelbrot set,
   z = z * z + c, but the other way around:

     In Step 1, z always started at 0, and c was a different
     point for each pixel.

     Here, c is one point you choose, the same for every
     pixel, and z starts at the pixel's point.

   The Julia set for c is all the starting points where z
   stays small forever. Every c gives a different Julia set,
   so there are infinitely many of them. They are named after
   Gaston Julia, who studied them, along with Pierre Fatou,
   around 1918, long before computers could draw them.

   The Mandelbrot set is like a map of all the Julia sets. If
   c is in the Mandelbrot set, its Julia set is one connected
   piece. If c is outside it, the Julia set breaks apart into
   scattered dust. Points of c near the edge of the
   Mandelbrot set make the most detailed Julia sets. Just
   outside the edge, like the c this sketch starts with, the
   dust is so fine that it still looks like one piece.

   Points in the Julia set are colored insideColor. Points
   outside it are colored by how many steps z took to get far
   away, the same way Step 1 does it.

   Press PLAY. It takes a few seconds. The picture is also
   saved as picture.pdf.

   THE VALUES YOU CAN CHANGE

     cx, cy            the point c, written cx + cy*i
     viewCenterX,
     viewCenterY       the point in the middle of the picture
     viewWidth         how wide the picture is, in the
                       equation's numbers. Smaller zooms in
     maxSteps          how many steps to try before deciding
                       z stays small
     dotsPerInch       how many pixels per inch in the picture
     paperColor        the color of the paper
     edgeColor         the color near the edge of the set
     insideColor       the color of the set

   THE EQUATIONS

   The step from Step 1. With z = x + y*i and c = cx + cy*i:

       newX = x * x - y * y + cx
       newY = 2 * x * y + cy

   Here x and y start at the pixel's point, and the steps
   stop when:

       x * x + y * y > 4

   The color outside the set:

       fraction = log(1 + steps) / log(1 + maxSteps)
       color = lerpColor(paperColor, edgeColor, fraction)

   =========================================================== */

import processing.pdf.*;

// ---------- THE PAGE ------------------------------------
int pageWidth = 792;     // 11 inches when printed, sideways
int pageHeight = 612;    // 8.5 inches when printed
float pageMargin = 72 / 4.0;   // a quarter inch when printed

int dotsPerInch = 100;   // how many pixels per inch in the picture

// ---------- THE JULIA SET -------------------------------
float cx = -0.8;
float cy = 0.156;

// ---------- THE VIEW ------------------------------------
float viewCenterX = 0;
float viewCenterY = 0;
float viewWidth = 3.6;

int maxSteps = 300;

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);   // white
color edgeColor = color(110,  30, 160);   // violet
color insideColor = color( 35,  10,  20);   // dark wine

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
// the picture fills the page inside the margins
float pictureWidthOnPage = pageWidth - 2 * pageMargin;
float pictureHeightOnPage = pageHeight - 2 * pageMargin;

// the picture's size in pixels. There are 72 points in an inch
float pixelsPerPoint = dotsPerInch / 72.0;
int pictureWidth = round(pictureWidthOnPage * pixelsPerPoint);
int pictureHeight = round(pictureHeightOnPage * pixelsPerPoint);

// the view is as tall as it needs to be to match the picture's
// shape, so nothing is stretched
float viewHeight = viewWidth * pictureHeight / pictureWidth;

// ---------- THE DRAWING ---------------------------------
void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);   // keeps the PDF the same size as the window
}

void setup() {
  noLoop();   // draw once, then wait
}

void draw() {
  PImage picture = createImage(pictureWidth, pictureHeight, RGB);
  picture.loadPixels();
  for (int row = 0; row < pictureHeight; row++) {
    for (int column = 0; column < pictureWidth; column++) {
      // z starts at this pixel's point. y goes up in the
      // equations but down the rows, so it is subtracted
      float x = viewCenterX + viewWidth * ((column + 0.5) / pictureWidth - 0.5);
      float y = viewCenterY - viewHeight * ((row + 0.5) / pictureHeight - 0.5);

      // step z until it is far away, or maxSteps is reached
      int steps = 0;
      while (steps < maxSteps && x * x + y * y <= 4) {
        float newX = x * x - y * y + cx;
        float newY = 2 * x * y + cy;
        x = newX;
        y = newY;
        steps++;
      }

      color pixelColor;
      if (steps == maxSteps) {
        pixelColor = insideColor;
      } else {
        float fraction = log(1 + steps) / log(1 + maxSteps);
        pixelColor = lerpColor(paperColor, edgeColor, fraction);
      }
      picture.pixels[row * pictureWidth + column] = pixelColor;
    }
  }
  picture.updatePixels();

  beginRecord(PDF, "picture.pdf");
  background(paperColor);
  image(picture, pageMargin, pageMargin, pictureWidthOnPage, pictureHeightOnPage);
  endRecord();
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     float cx = -0.123;   // Douady's rabbit: a blob with ears,
     float cy = 0.745;    // named after Adrien Douady

     float cx = -0.75;    // San Marco: named for the domes of
     float cy = 0;        // the cathedral in Venice

     float cx = -0.835;   // a twisting chain of spirals
     float cy = -0.2321;

     float cx = 0;        // a dendrite: thin branches with no
     float cy = 1;        // inside at all

     float cx = 0.3;      // fat spirals, swirling around
     float cy = 0.5;      // the middle

     float cx = 0.285;    // c is just outside the Mandelbrot
     float cy = 0.01;     // set, so the Julia set is dust

   =========================================================== */
