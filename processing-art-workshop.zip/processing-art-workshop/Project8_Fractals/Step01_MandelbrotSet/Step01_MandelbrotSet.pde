/* ===========================================================
   STEP 1 — THE MANDELBROT SET
   ===========================================================

   PROJECT 8 — FRACTALS

   Pick a point c. Start z at 0, and over and over, square z
   and add c. For some points, z stays small forever. For
   others, it grows and races off toward infinity. The
   Mandelbrot set is all the points where z stays small.

   Its edge is a fractal: zoom in anywhere on it and there is
   always more detail, including tiny copies of the whole
   set. It is named after Benoit Mandelbrot, who made the
   first detailed computer pictures of it at IBM in 1980.

   Each pixel of the picture is one point c. Points in the
   set are colored insideColor. Points outside it are colored
   by how many steps z took to get far away: ones that
   escape right away are close to paperColor, and ones that
   take many steps, which are close to the edge of the set,
   are close to edgeColor.

   Press PLAY. It takes a few seconds. The picture is also
   saved as picture.pdf.

   THE VALUES YOU CAN CHANGE

     viewCenterX,
     viewCenterY       the point in the middle of the picture
     viewWidth         how wide the picture is, in the
                       equation's numbers. Smaller zooms in
     maxSteps          how many steps to try before deciding
                       z stays small. Zoomed in, more steps
                       show more detail but take longer
     dotsPerInch       how many pixels per inch in the picture
     paperColor        the color of the paper
     edgeColor         the color near the edge of the set
     insideColor       the color of the set

   THE EQUATIONS

   z and c are complex numbers: each is a point x, y, written
   x + y*i, where i * i = -1. The step is:

       z = z * z + c

   With z = x + y*i and c = cx + cy*i, multiplying out
   z * z and using i * i = -1 gives:

       newX = x * x - y * y + cx
       newY = 2 * x * y + cy

   Once z is more than 2 away from 0, it always races off,
   so the steps stop when:

       x * x + y * y > 4

   The color outside the set:

       fraction = log(1 + steps) / log(1 + maxSteps)
       color = lerpColor(paperColor, edgeColor, fraction)

   =========================================================== */

import processing.pdf.*;

// ---------- THE PAGE ------------------------------------
int pageWidth = 792;     // 11 inches when printed, sideways
int pageHeight = 612;    // 8.5 inches when printed
float pageMargin = 72 / 4.0;   // a quarter inch when printed

int dotsPerInch = 100;   // how many pixels per inch in the picture

// ---------- THE VIEW ------------------------------------
float viewCenterX = -0.75;
float viewCenterY = 0;
float viewWidth = 3;

int maxSteps = 200;

// ---------- THE LOOK ------------------------------------
color paperColor = color(255, 255, 255);   // white
color edgeColor = color(  0, 130, 200);   // azure
color insideColor = color( 20,  15,  40);   // midnight

// ---------- WORKED OUT FROM THE NUMBERS ABOVE -----------
// the picture fills the page inside the margins
float pictureWidthOnPage = pageWidth - 2 * pageMargin;
float pictureHeightOnPage = pageHeight - 2 * pageMargin;

// the picture's size in pixels. There are 72 points in an inch
float pixelsPerPoint = dotsPerInch / 72.0;
int pictureWidth = round(pictureWidthOnPage * pixelsPerPoint);
int pictureHeight = round(pictureHeightOnPage * pixelsPerPoint);

// the view is as tall as it needs to be to match the picture's
// shape, so nothing is stretched
float viewHeight = viewWidth * pictureHeight / pictureWidth;

// ---------- THE DRAWING ---------------------------------
void settings() {
  size(pageWidth, pageHeight, P2D);
  pixelDensity(1);   // keeps the PDF the same size as the window
}

void setup() {
  noLoop();   // draw once, then wait
}

void draw() {
  PImage picture = createImage(pictureWidth, pictureHeight, RGB);
  picture.loadPixels();
  for (int row = 0; row < pictureHeight; row++) {
    for (int column = 0; column < pictureWidth; column++) {
      // the point c for this pixel. y goes up in the equations
      // but down the rows, so it is subtracted
      float cx = viewCenterX + viewWidth * ((column + 0.5) / pictureWidth - 0.5);
      float cy = viewCenterY - viewHeight * ((row + 0.5) / pictureHeight - 0.5);

      // step z until it is far away, or maxSteps is reached
      float x = 0;
      float y = 0;
      int steps = 0;
      while (steps < maxSteps && x * x + y * y <= 4) {
        float newX = x * x - y * y + cx;
        float newY = 2 * x * y + cy;
        x = newX;
        y = newY;
        steps++;
      }

      color pixelColor;
      if (steps == maxSteps) {
        pixelColor = insideColor;
      } else {
        float fraction = log(1 + steps) / log(1 + maxSteps);
        pixelColor = lerpColor(paperColor, edgeColor, fraction);
      }
      picture.pixels[row * pictureWidth + column] = pixelColor;
    }
  }
  picture.updatePixels();

  beginRecord(PDF, "picture.pdf");
  background(paperColor);
  image(picture, pageMargin, pageMargin, pictureWidthOnPage, pictureHeightOnPage);
  endRecord();
}

/* ===========================================================
   TRY THESE (change a value, press PLAY, see what's different):

     int maxSteps = 10;          // a blobby outline: not
                                 // enough steps to find the
                                 // edge

     float viewCenterX = -0.7436;   // Seahorse Valley, in the
     float viewCenterY = 0.1318;    // gap between the two
     float viewWidth = 0.006;       // biggest parts
     int maxSteps = 500;

     float viewCenterX = 0.2925;    // Elephant Valley, in the
     float viewCenterY = 0.016;     // dent on the right
     float viewWidth = 0.01;
     int maxSteps = 500;

     float viewCenterX = -1.77;     // a tiny copy of the whole
     float viewCenterY = 0;         // set, out on the spike
     float viewWidth = 0.06;        // to the left
     int maxSteps = 500;

   =========================================================== */
